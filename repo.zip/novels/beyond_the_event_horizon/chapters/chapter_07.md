# Chapter 7: Bounty on the Ghost

The cacophony of frantic footsteps, grunts of exertion, and crunching impacts reverberated down the labyrinthine tunnels carved into the orbiting habitat ring. Laser fire strobed wildly in flickering patterns along the metallic walls, casting eerie dancing shadows across the faces of countless panicked civilians who thronged the narrow alleys, desperately seeking shelter from the murderous melee unfolding above.

Astrid 'Vex' Ross crouched low beside Commander Leo Mercer, her crimson-hued armor glinting menacingly beneath the harsh fluorescent lights that striped the passage with sickly shades of bilious green and cadaverous blue. She squeezed off precise rapid-fire bursts from her pulse pistol at hostile figures emerging greedily from side passages, each supersonic snap of her weapon sending plumes of gray dust and chipped ceramic flying.

"Hold your fire!" Leo yelled, risking a peek around the corner before yanking back in reflexive response to the barrage of bullets raining down from the next intersection ahead. "We're running out of ammo!"

Vex ground her teeth, her emerald eyes narrowed into fiery slits as she spat out a string of curses under her breath. Their pursuit was relentless – relentless and well-coordinated. Every indication pointed toward several pirate syndicates converging on their position in tandem, aided perhaps by clandestine Dominion agents eager to claim a piece of the astronomical bounty now supposedly riding shotgun aboard Starlight.

"This was supposed to be a safe retreat!" Vex growled, snapping another clip into place with practiced hands. She glanced sidelong at Mercer, noticing the dazed look creeping over his features despite his stalwart demeanor. "Merc, snap out of it! We were only a few jumps from extracting ourselves – no telling how much longer it'll take us to shake these dogs now."

Her words seemed to rouse him, for he nodded curtly and took aim again, working methodically to pick off threats rather than simply hosing fire indiscriminately. The combination of lethal precision and sheer determination pouring from his stance sent a thrill stirring beneath Vex's ribcage – even as the realization punched her like a fist to the gut that they still had no clear idea where the hell they were headed, much less whether Starlight would last long enough to get them there.

"Cover me," Vex barked to her crewmate as she rose fluidly to her feet, bringing up her heavy grav rifle instead of the pint-sized sidearm. Sweat trickled down her face, stinging eyes rimmed red from grit and exhaustion, yet her movements remained smooth, unhurried, calculated - those of a warrior utterly attuned to the rhythms of violence.

"Blast shields!" Mercer called out, activating a shimmering translucent barrier just as Vex triggered the first shot, a thunderous roar resounding through the tunnel as antimatter rounds pierced the air. Sparks flew, and concrete crumbled as the opposing team's defenses shattered under the onslaught.

In the flickering lull that followed, Vex risked darting forward, plastering herself against the wall with muscles coiled tight as a tightly wound spring. Her free hand scrabbled across the metallic surface for handhold before launching herself into a series of dizzying flips and somersaults, momentum carrying her over obstacles and nimbly avoiding the next wave of incoming fire.

Leo watched her deft maneuvers in stunned awe, heart pounding wildly in his chest even as a hint of queasy nausea threatened to overwhelm him with its intensity. He couldn't remember the last time he'd witnessed someone move so fluently, smoothly shifting vectors mid-leap and adjusting courses on the fly with unerring precision...

"All right!"

✦ ✦ ✦

As Leo's awestruck gaze lingered on Vex's acrobatic feats, their surroundings erupted anew in a cacophony of clashing fire and screams from the simulation team struggling to regain footing.

"We're getting pummeled out here, Captain!"
"I have weapons lock—"
"Weapons systems down! Shields at twenty percent!"

The chaos reigned for mere moments before subsiding into desperate attempts to regroup. Amid the din, Leo felt Astrid slide close beside him, her warm breath ghosting against his ear as she barked orders terse as laser strikes:

"All three of you fall back to secondary positions. Aim for overload. Hit shields then engines – we need to cripple them, not just keep them occupied." As if to demonstrate, the bounty hunter sent another salvo rocketing down the corridor, this time targeting the vulnerable power nodes with surgical precision. The resulting blast lit up the confined space like hellfire, shadows dancing grotesquely across scorched walls and sending debris plummeting to the floor.

Mercer flinched instinctively even though they were safely tucked behind reinforced barriers designed to withstand such attacks. His skin prickled with the sheer force of it, sweat mixing with cooling system mist to trickle icily down his spine. Unbidden, the echoes of comrades felled by similar barrages back during the Chorus War resurfaced, threatening to plunge him into old, grim memories best left buried...

No – now wasn't the time for introspection. Not when their digital assailants were still very much active, probing vulnerabilities in their defenses with relentless, remorseless aggression.

"All right," Astrid repeated once the shockwave receded, her focus unnervingly razor-sharp despite the turmoil erupting around them. "We've got the high ground. Now it's our turn to dictate rhythm."

She turned to him, hazel eyes hard as gemstones in the strobing emergency lights. "Leo – I want you to work backup from station C6-12 near the main hub with Nix and Kaela. Remember your flight training? Tactical simulations, stress tests?"

A nod and grunt acknowledgment.

"You'll need to coordinate assault fire patterns, try to create windows to target structural weaknesses in their formation. Understood?" The last word hung in the charged air between them as she awaited his response, the intensity of her stare almost palpable across the gap separating them.

McCormick, watching the exchange with hawkish interest, interjected with a low, rumbling growl, "Cap'n, if this keeps up much longer we won't have choices to make – we'll be purely reacting. Need to end this fight soon."

Vex merely glanced at the grizzled tactician and shrugged, returning her piercing gaze to Leo once more. There, etched within those molten depths, was an inscrutable mix – respect perhaps for his skill, annoyance at being put in charge alongside a relic from two centuries previous, but also something else he couldn't quite decipher...

Whatever that enigmatic emotion might be, Leo knew one thing for certain – in this moment, amidst the heat of combat and the flashing neon signage advertising exotic imports, they both stood at a crossroads. One misstep could lead to catastrophic consequences for both their careers and the precarious trust that had begun forming between two disparate souls operating on irreconcilably different wavelengths.

Drawing a shaky lungful of oxygen into his diaphragm, Major Commander Leo Mercer steeled himself for battle – fighting not just for simulated domination on a digital battlefield, but for the fragile bond he dared harbor amidst an unforgiving cosmos full of uncertainties waiting to gnaw apart the threads holding their t.

✦ ✦ ✦

Vex barked her orders, voice clipped and authoritative as she surveyed the digital chaos unfolding across the holo-projected battlefield. "Red, divert max cannons to portside. Green, aim your plasma torpedoes at the enemy's command ship! If anything gets past, Black, pivot and cover our retreat, got it?"

Leo worked the virtual controls with practiced ease, a rhythmic dance of thumbs and fingers navigating the tactical complexities of a fleet engagement while simultaneously keeping a wary eye on his unpredictable Corsarian counterpart. He had to admit, even though her tactics were aggressive bordering on reckless, a certain respect grew for her cunning and ability to adapt on the fly. After all, that same unorthodox style had led him to capture her prized vessel in the first place – an irony that never failed to amuse.

As if sensing his observation, Astrid's gaze flickered towards him, momentarily leaving its relentless focus on the holographic mayhem. For a fleeting instant, he could have sworn he caught a glimmer of what looked astonishingly like camaraderie shared between two kindred spirits in mutual adversity. But then the inferno of her stare returned, pinning him where he sat. A pulse of electricity tingled down his spine; he resisted the sudden impulse to look away or fidget under her intensity, instead choosing to return the unspoken challenge head-on.

Meanwhile, reality outside their armored glass bubble remained blissfully indifferent to their conflict. Neon advertisements flashed and scrolled along the docking bay's walls like dizzy banners of commerce chasing profit amidst war and intrigue -the dissonant backdrop against which these vastly disparate individuals found themselves forging fragile bonds.

Within their air-tight spacecraft, each shared breath was a countdown, measured out by steady heartbeats and the metallic whirr of instruments under strain. Recycled oxygen and copper filled the lungs, the musky funk of adrenaline seeping beneath the scent. Sweat beads trickled through tangled hair, pooling on brow creases carved by the relentless glisten of cold light reflected off circuitry. Each heavy exhale was an acknowledgement of their shared predicament, the knowledge that so much hung in the balance -careers, loyalties, and maybe, just maybe, nascent feelings born in extreme conditions like some primal spark waiting only for tinder fuel to erupt.

Just as he sensed Astrid's gaze start to shift once more, focusing back on tactics, Leo felt his console vibrate beneath his palms. His eyes widened as red warning flags blossomed across the schematics. Something major had went wrong. With a gut-wrenching lurch, he realized they'd suffered critical damage amid the frenzied onslaught, forcing them to cut power to defensive systems simply to keep key systems online.

With icy calm, Vex assessed the situation with calculating precision. "Looks like the bastards tagged us with a lucky salvo. We're hemorrhaging atmosphere fast and shields are shot."

Realization dawned that their prize victory may slip through their grasp, snatched away in the cruel ebb of fortune's currents. Still, neither commander seemed prepared to yield. Leo's lips thinned in grim resolve, heart pounding a primal cadence; Astrid, ever the unyielding predator, her features smoothed into an almost serene mask betraying no hint of panic. In this crucible, forged in bloodless digital battlespace dusted by stars, the lines blurred—replacing petty rivalry with an instinctual unity driving forth twin wills in concert. They would not fall today. Not without taking every last hostile target with them.

✦ ✦ ✦

The Marauder surged forward, straining against her bonds of gravity and thrust. Atmosphere frosted the gaping scars marring her hull, eerie pearlescent rivulets tracing the ragged trajectories of bullets seared through her vitals. Alarms screeched and flashed at every sensor, a digital requiem tolling the death knell of shredded defenses.

Astrid stood ramrod straight, fists clenched white-knuckled against her armrests, jaw squared in unwavering determination. Her gaze flicked errantly, scanning dashboards for an anchor amidst tempestuous chaos, before settling again upon Leo flanking her command chair. Her narrowed eyes conveyed a promise of fiery retribution.

Leo returned the look unflinchingly, the scar above his left eye twitching in sympathetic rhythm with his accelerated pulse. He could taste the metallic tang of anxiety on the back of his tongue, a primitive echo of countless G-forces and high-stakes flight-test simulations long forgotten in the yawning chasm of time. 

Together, they rode the Marauder's heaving frame, a counterpoint symphony of urgency and purpose, poised on the razor's edge between desperate flight and brazen retribution. Amidst the acrid stench of ozone and charred circuitry seeping into the cockpit, amidst the deafening susurrus of emergency alerts wailing through speakers, something shifted. A threshold crossed.

Vex barked crisp commands, fingers dancing over consoles with preternatural speed, leveraging decades of piratical experience in high-stakes combat. She divested them of precious velocity with savage abandon, hurtling into open blackness at suicidal vectors until mere proximity detonated her stores of exotic ordnance amidst the enemy fleet's clustered configuration.

Marauder shook like a wild animal as retaliatory hellfire stitched blazing trails through their own hull. Explosions boiled off in gouts of fire and shrapnel, each concussive impact jarring the fighters' bones. Hatches blew out in showering clouds of debris; bulkheads groaned ominously beneath the merciless stress of structural integrity failing.

Through it all, Astrid merely gritted her teeth, focused on what little remained undetonated within magazines and launch tubes. Leo clung to the co-pilot's seat, arms pressed tightly to the console for stability, watching ghostly blue force fields strobe onscreen as increasingly frail defenses blunted the relentless assault. Together, they awaited the final reckoning, riding their hurtling, burning, dying ship into the jaws of oblivion.

As suddenly as the maelstrom erupted, it ceased. A stunned, echoing silence filled the cockpit, punctuated by the steady hiss of emergency venting oxygen into vacuous darkness. Blinking away the blur of motion, Leo registered the scene unfolding outside.

Nebula tendrils writhed sinuously past shattered windows in mesmerizing displays of radiant color, as if titanic serpents danced amidst star-birth birthing nascent worlds. Celestial dust illuminated by nearby stellar radiation glimmered like stardust sprinkled across canvas-black velvet, a breathtaking tableau revealing previously unseen wonders normally veiled in opaque interstellar haze.

And there, etched stark against the swirling cosmos, sprawled the detritus of destroyed ships, skeletal remnants floating serenely amidst the nebulon soup. Salvagers would later strip the husks down to their component metals; for now, under the pitiless light of distant suns, the remnants served as macabre monuments to futility and loss.

Astrid's voice broke the spell of awestruck reverie. "Contact incoming..."
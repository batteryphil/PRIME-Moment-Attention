# Chapter 4: The Scavenger's Code


Vex's words broke through Leonardo's trance like thunder, her voice low and razor-edged:

"Don't just stand there, cowboy, we're about to get eaten alive!"

He snapped out of his daze and scrambled into the co-pilot chair, clenching his teeth at the acrid scent of scorched plastic that still adhered to his gloves from the last close call. Across the cockpit, static-crackle warnings pulsed in crimson against the schematics scrolling across Vex's main display, marking the inexorable approach of their pursuers.

"Hold on," she grunted, wrestling the yoke to port and applying full reverse thrust. The Marauder's afterburners ignited, concussive vibrations thrumming violently through the deckplates, a searing blast that coated the viewing ports with a thin layer of thermal black slag from the ceramic heat shield. Even through reinforced earplugs, the kinetic shockwave shuddered through the airframe like a tidal surge, rattling fillings and pounding in their skulls. Outside, they could feel the ship shuddering under the blistering onslaught of energy and exotic matter projectiles spewing forth from incoming ships.

Leo's stomach churned as the acceleration ripped him back against the seat harness, the g forces crushing down with merciless precision. His vision swam behind a red veil, eyelids fluttering as synapses screeched in protest at the abrupt shift in inertial reference frames. He had faced hellish, beyond-redline maneuvers during stealth run practice back on Earth, but such sustained, unaided violence as this shattered his understanding of human endurance. What kind of monsters could withstand such punishment for extended minutes on end?

Vex swore colorfully as another direct hit rocked the vessel sideways, the shockwave ripping loose a hatch cover and sending jagged aluminum shards ricocheting wildly through the control room. Wires thrashed around like panicked serpents and console displays flickered at random before plunging into darkness. Smoky gray fumes wafted ominously past the vents.

She hauled on the controls, desperate to break their predictable course profile before the pursuit adjusted its targeting solutions. Amid the silent, deadly chaos of vacuum outside, Leo barely registered the disorienting sensation of the maneuver: the universe careened into oblivion behind them as a high-gravity drift pushed their mass toward the center of curved spacetime – then, abruptly released, swung them screaming back across the void.

For a moment that felt eternal, weightlessness enveloped them, stars and galaxies streaking past the viewports like celestial graffiti in a shooting gallery. Then artificial gravity sprang back online, slamming Leo so hard against his restraints that he could taste blood. His head throbbed and his ears rang, threatening to burst with each frenetic heartbeat.

"Did we—" Vex gasped for breath between clenched teeth. "Did we lose—?"

Her words cut off as a proximity alarm wailed, shrill and insistent. They both whipped their heads towards the tactical readouts, dismay etched on their faces as the new threat icon resolved into stark, unforgiving lines.

"A second wolf pack!" Leo slammed a fist onto the armrest, eyes bulging. "They're surrounding us! How are we supposed to—"

"We fight," Vex snarled, drawing herself up like a coiled spring. Her gaze flickered briefly to Leo, a silent assessment of his readiness filtering behind those amber eyes. "On my mark, prep for a hot extraction launch. We'll outrun these bastards on scramjets."

"But—"

"Not this time, Tex. We ain't built for a fair fight."

✦ ✦ ✦

Leo's nostrils flared at her dismissal of his strategy, but he bit back the retort brewing on his tongue. This wasn't some simulator flight where they argued procedures until they got it right. This was real, every searing second of it.

He leaned closer to study her face, trying to peel back layers of hardened cynicism and read what might truly motivate this lethal woman who commanded a gunship crew of rough-cut smugglers. He probed gently for fear, for doubt anywhere beneath her bravado.

"What changed, Vex? Why can't we try to even the odds?"

The pirate captain didn't hesitate, her reply as swift and bitter as vitriol. "Because, Mercer, you live by the stick-to-your-plan rule – die by it too, if need be. But I learned, the hard way, to never expect courtesy from a universe full of cold, uncaring fucks. Survival means cutting losses, playing dirty. Even our own hide's expendable if it suits."

Her words hit like daggers, and not just because they echoed chilling truths about his own outlook. There was a deeper hurt there, a gash left bleeding raw by past betrayals and sacrifices she'd made for this harsh existence. He saw the cost etched in her weathered features, heard its shadow in her voice.

"We're not always deal-breakers," he countered quietly. "Sometimes people still stick by each other, no matter how rough things get. You can't trust me yet, fine, but know one thing – I'm not going anywhere until I've earned it."

Vex let out a short, humorless laugh devoid of warmth. "Earn it, huh? Maybe out there, somewhere in our lifetime, men and women will find loyalty and honor as valuable commodities again. But until then, we grab what power we can and use it however it gets results. No more talking philosophy."

She turned away to address her crew, snapping orders whose harsh timbre sent tremors down the length of the bridge. "Caleb, get us running lights – want these pigs chasing an easy meal while we slip the noose. Nix, prepare aft cannons for rapid-fire overheat. And you, Tex..."

"Still with you, Cap'n," Leo replied firmly, meeting her piercing gaze without flinching. He knew this dance – the push-pull of two strong personalities clashing, neither willing to cede ground. It threatened to become a drawn-out struggle, pitting tradition against pragmatism, principle against pure instinct to survive.

"You just remember what a powder keg awaits any false move. Keep your wits sharp, keep your focus sharp – or we'll all be powder before the night's done."

With that blunt warning, Vex pivoted away, striding purposefully towards the command chair. The silence stretching behind her was as thick as space itself – an unspoken challenge hanging heavy with anticipation of what came next, what alliances would shift, and what lives would hang precariously in the balance.

The Starlight Marauder shuddered once, twice, and then lurched forward into the unknown, leaving the dwindling silhouette of their pursuers to pursue their futile chase across infinity...

✦ ✦ ✦

"Acknowledged," Leo called out over the dinning klaxon. His fingers danced nimbly over the control array, muscles tensed and ready to respond at a millisecond's notice. This wasn't flying – it was high-stakes roulette, one bad decision spiraling towards catastrophe on the unforgiving stage of hard vacuum.

Through the viewscreen, the expanding crimson afterburn marked the Marauder's desperate run for cover amid the sapphire swirls of the nebula ahead. The pursuing frigates blinked like angry fireflies on Vex's tail, their aggressive vector projections careening heedlessly off dark, icy asteroid chunks scattered throughout the turbulent cloud.

"Hold steady!" Vex bellowed, eyes fixed rapt on the navigational display. Her voice was a snarl, clenched jaw betraying the taut coils of pent-up fury coiled within.

Leo nodded curtly in understanding. "Gotcha."

The frigate squadron's blistering acceleration pushed the decks of the Marauder into their faces, throwing both pilot and captain ruthlessly into their harnesses. Even with advanced gravity compensators, there could be no hiding the sheer force slamming mercilessly into them, a bone-jarring reminder of which side truly held the upper hand in this lethal game of cat and rodent.

"Goddammit!" Caleb swore loudly beside him, straining against his own restraints while he fought furiously to wrestle errant photon turrets back under manual control. The light-sensitive focusing arrays were overwhelmed by the dazzling glare streaming in through the viewscreens, creating a brief window of instability that an alert foe could exploit with devastating consequences. The young gunner's face contorted in concentration, forehead streaked with sweat slicking dark hair to his scalp.

With the ship already stretched to its dangerous capacity, any additional damage risked catastrophic cascading failure. Not to mention jeopardizing the delicate trust already fraying between commander and captain as they hurtled headlong into a cauldron of treacherous celestial debris... 

A shrill beep pierced through the cacophony, drawing both of their attention to the ominous orange flash warning blinking insistently atop Leo's console. Crimson words flashed across the display - Plasma Containment Breach Imminent!

With rising dread, he tracked the readings racing wildward toward critical threshold -- every second bringing them perilously closer...

"Fu--"

He cut himself off, voice hoarse and raw. Vex was already moving, grabbing at emergency shut-offs on impulse even as she roared out orders--

"Shields up! Leo, purge those thrusters and feed the excess power to the reactors--now!"

Bare inches separated them, bridging the small space to where he sat hunched over the controls. For one fleeting instant, his eyes met hers - smoke-colored irises blazing with adrenaline and desperation. Time stretched to elastic lengths, each moment feeling as long as a century amidst their mounting chaos. Vessels pounded against ribcages and temples, the pressure so acute it threatened to burst lungs and brains alike.

Then suddenly the inferno raging in their core surged, and the marauder leaped straight into the abyss... The violent thrust jerked mercifully slack, but gravity remained brutally inescapable, throwing the two back brutally against their restraints once more, only this time with the added bonus of searing pain igniting along their sinews whenever they tightened even minutely...

Trembling, gasping, disheveled with shock and exertion, they sat for a few precious seconds immersed in stunned silence broken only by the mournful sigh of superheated plasma venting harmlessly into the void.

✦ ✦ ✦

Panting raggedly, their chests still heaving like bellows through layers of scorched flight suits, the commander and the captain stared blankly ahead, struggling to process the harrowing crescendo just past. The metallic acrid stench of burnt wiring and charred ablative hung heavy in the stuffy air recycled through the Starlight Marauder's life support.

Bare centimeters separated them, closing like the fragile boundary between life and oblivion during those hellish seconds when catastrophe loomed large enough to consume them whole. When death knelt menacingly at their threshold.

Leo's mind reeled, replaying the frantic dash around the cockpit to slap emergency overrides onto unresponsive systems. Every nerve screamed from the punishing forces still reverberating through his battered frame—each twitching muscle fibers crying out for respite that didn't come. Sweat trickled down his brow, beading into rivulets on dust-caked skin as a new chill started creeping in to numb his flesh to the bone.

Beside him, Astrid too seemed frozen—eyes glazed and distant behind mask-like features set hard beneath a wild tangle of wind-tousled platinum hair. Her fingers clenched spasmodically on her harness straps, trembling as if trying to shake off a lingering afterimage of terror.

Leo cleared the grit from his throat, willing his voice steady as he addressed his captain without looking away from her face. "I think we made it..." The words came out weak, rusty, but certain. A note of cautious triumph crept into his tone—the first hint of relief in their strained conversation thus far.

Without waiting for a response, the commander shifted uncomfortably against his crumpled seat, testing the limits of his bruised back and joints. His ribs still ached viciously, protesting every shallow drag of his breath through mangled, smoke-weary lungs, but at least the constant clamor of alarms had fallen eerily silent.

Astrid blinked slowly, regaining traction in her thoughts. "Shields?" Her voice sounded husky, almost intimate—a stark contrast to the commanding timbre usually laced with steel. She reached over to flip open a glowing screen on the console before them. Frowning, she scanned the readouts—a web of pulsing lines and flashing warning icons.

"No breaches," she announced finally, satisfaction hardening her expression almost imperceptibly. Though the display indicated numerous system overloads and thermal fluxes requiring manual override adjustments, nothing critical had given way under the onslaught—that much was clear.

Leo nodded, slowly exhaling the pent-up tension. "Looks like we weathered the worst of it then..."

Just as the captain opened her mouth to offer some reassurance or acknowledgment, the Marauder jolted violently, throwing both occupants sharply forward against their restraints once more. This time no panicked red alerts ripped across the comms or lights flared outside their bubble—only a stomach-dropping plunge that left hollow, quivering pits in Leo's gut and sent the stars streaking across the viewport in dizzying patterns.

Astrodynamics 101 dictated impossible speeds were involved—numbers that meant the pirate vessel must have breached the event horizon of a massive black hole...

Vessels groaned ominously under the unseen centrifugal force dragging the ship deeper into incomprehensible velocities. Searing heat began radiating through the cabin walls as energy normally lost to the star-choked void surged back along trailing magnetic fields—every cubic inch of metal becoming a scorchingly hot filament screaming toward oblivion.

Gravity waves shook the Marauder on its axis like a toy tossed in tempestuous surf.
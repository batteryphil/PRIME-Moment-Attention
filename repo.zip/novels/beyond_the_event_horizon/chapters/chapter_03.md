# Chapter 3: A Thousand Years from Home


Leo careened across Medical Bay Zeta 7 in a frantic, lurching tumble - the result of a sudden, hard negative acceleration jolted through the Starlight Marauder's deckplates like an electric shock. Even encased in emergency restraints, his body slammed painfully against a bulkhead fitted with shock-absorbing padding. Breath stolen away by the brutal G-force, Leo watched the medical instruments along the exam table spin out of focus before his half-lidded gaze. His heart thundered in his ears like cosmic artillery fire, overwhelming even the warbling klaxon alarm that shrieked an urgent warning throughout the damaged ship.

When the Marauder finally relinquished its tight-radius turn, Leo sagged back into his restraints, fighting for each panting inhalation as stale oxygen hissed from his mask. Cold sweat slicked his forehead – not just from the adrenaline crashing through his system but the bitter chill seeping from every metallic surface in the medbay. Fluorescent lights hummed malevolently overhead, strobing cadaverously in time with the red combat alerts crawling across the status displays lining the walls.

Orlo's synthesized voice cut through the cacophony of alarm systems. *“Lieutenant Commander, report to the bridge immediately. Captain requests your expertise assessing—”* The communications officer's transmission was interrupted by a bone-rattling impact shuddering through the ship’s hull, kicking up a loud bang! of suppressed explosive decompression that echoed ominously despite being muffled by the thick armored plating. Dust motes danced lazily amidst the reddish combat lighting seeping under the seals, heralding breaches somewhere in the starship's vulnerable superstructure.

"Mercer, move!" Vex snatched up a medkit from the nearby cabinet and jammed it under one arm, her other gripping his sleeve as she dragged him toward the bay door and the distant hubbub of the bridge. She pulled him into a cramped utilitarian lift, jabbing a finger at the brass panel controlling access to various decks. The lift cycled shut behind them, clanking groaning protests as it descended five levels into the nerve center of the renegade corvette.

The bridge door irised open with a hiss of pressurized gases escaping containment, revealing a cacophonous chaos of urgent activity playing out across the command center. Tactical crew members swarmed about control consoles and holo-projections, voicing frantic queries and spitting orders that flew past as the corridor shook again – a deeper, more ominous tremor.

Leo struggled free of Vex's grip as they crossed the threshold, stumbling towards the main viewport overlooking vast starry expanse lit by orange nebular clouds and distant blue-white suns. His vision narrowed to pinpoint clarity around the shimmering glass as he saw a dark silhouette materialize from the swirling stardust outside - a deadly piranha-shaped capital warship easily twice the size of the Marauder. The looming dreadnought filled several dozen degrees of angular view within the cockpit, details resolving to ominous flanks bristling with weapon arrays and missile racks. Its blackened matte finish seemed almost to drink in the ambient starlight, radiating an aura of ruthless menace.

"Captain, I'm coming up on tactical—" a young ensign said urgently, gesturing to a flickering 3D projection hovering beside her station, depicting the Dominion warship at varying angles and altitudes relative to the dogfight unfolding outside.

✦ ✦ ✦

The mariner's gaze locked onto the dreadnought like steel clamping iron as they hung suspended mere furlongs from its black hull amid the disquieting stellar dance beyond the transponder-coded armor plating. A chill slithered down Leo's spine at the sheer scale and malevolent presence emanating from this instrument of conquest, a harbinger of devastation wielded by those who called the stars their dominion.

"Estimated velocity two hundred kps..." Astrid muttered beside him, eyes never leaving the main display as she monitored the sensor sweep painting the enemy ship in real-time tactical detail with shades of crimson and amber light. "...and gaining. She intends to engage, and likely intends us dead."

Leo's fists clenched involuntarily at his sides as conflicting instincts wrestled for dominance within his bloodied mind. As an experimental test pilot back home, every mission had been meticulously planned and briefed with primary objectives, secondary contingencies, and fail-safes layered so deeply it'd take a crack team years to unravel them if anything went sideways. No scenario in modern warfare protocols prepared him for this primal reality staring him in the face: in a cold, uncaring cosmos where empires birthed among stars razed entire civilizations beneath their heels without remorse.

"We cannot engage," he stated firmly, every calculated syllable biting into the air between them. "Even if we could somehow pierce her shields or outrun her defenses, which we're decidedly not equipped to do—"

"The hell we can't!" Astrid spat, whirling on her heel to confront him. Her fiery hair swirled about her shoulders like a living coalscapes as she cocked her hip, one hand resting atop the grip of the pulse-rifle slapped casually over her shoulder. "Out there is where we'll decide our fate, boyo - not cooped up cowering behind safety nets drawn 'round us eons ago!"

"That's precisely my point, Captain," Leo retorted, voice cracking with strain but resolve unwavering. "Those safety nets aren't archaic relics to be scorned with impunity. They safeguard us. They govern. And right now, they dictate retreat and regroup, rather than reckless... suicidal..."

"Recklessness isn't in the cards," his host captain interrupted coolly, a wraithlike smile curling the corners of her mouth. "We have means to overcome any predicament in these starlanes... for a price." Her smile widened, razor-fanged edges glinting wicked in the light reflecting off the dreadnought's obsidian flank. "Tell me, Mr. Commander, how willing are you to write off your home, your family, and quite possibly your precious soul – all to uphold standards that may as well be antiquated tombstones? Because if it comes down to that choice..." Her laughter was chilling as she turned to gaze once more upon the advancing juggernaut of war, voice laced with bitter amusement. "...Well, let's just say some graveyards ain't large enough for everyone involved."

✦ ✦ ✦

Leo's heart slammed in his chest, thunderous against his ribs as he locked eyes with Astrid. He could practically see the gears turning in her mind, the calculating thrum of her intellect matching the pulsing crimson lights etched into the Marauder's hull. Each passing second felt heavier, weighted by the unspoken gravity of their dilemma.  

Her question hung suspended like ice cubes clinking ominously in chilled vodka, posing the ultimate existential choice—loyalty to principle versus love for his kin. The notion that he might inadvertently send them all to oblivion gnawed at him, an ulcer eating away at self-respect and confidence equally.

Astrid awaited his response, her posture ramrod straight with barely contained anticipation. Those feral, incandescent eyes bored into him, demanding an answer that would forever reshape the trajectory of both their lives. Sweat trickled cold down his spine beneath the confines of his flight suit as the hum of engines reverberated through the cockpit, synchronizing their racing hearts. 

In that charged instant, their positions seemed inversely proportional to true power. She stood astride the void, master of her domain with its limitless possibilities. Meanwhile, he languished in a borrowed ship, subject of her whimsy—a relic stranded centuries past. The awareness pricked at him like a goad, stung by the unflattering truth.

And yet, even then, amidst the swirling tempests of doubt and fear, Leo found himself drawn to this piratical enigma who embodied chaos incarnate. His thoughts whirled, trying to compartmentalize the conflicting tides buffeting his every instinct—the nagging responsibility toward homeland duties, the magnetic pull of Astrid's unpredictable nature.

She read him so easily, this space-born femme fatal with a death wish, her predatory instincts sharper than any cutting-edge AI. In turn, Leo unraveled her, piecing together fragments of her past until the full scope emerged—a creature forged by untold cruelty and loss, tempered by an insatiable hunger for life's fleeting euphoria. He understood her better than anyone should, perhaps too empathetically.

The dreadnought loomed ever closer as they squabbled, blotting out stars and mocking their insignificance with each chug of its massive fusion drives. Time became fluid, stretching and dilating, while they clung to the precipice of action, indecision poised to plunge them both under.

Captain Vex's grin widened, the razor-edged gleam of teeth eerily beautiful as a darkling moon. "Make your decision swiftly, Leo. We dance on the cusp of fates far more dire than mere death."

Her laughter followed him as he retreated from the cockpit to gather his scattered thoughts beneath the cool canopy of metal and wires. Outside lay the abyss beyond reason, an unconquerable force testing loyalty, honor, humanity itself. Through the bulkhead panels, the war effort's dwindling fleet flickered by in eerie silence, their final stand mirroring his internal battle.

As he stood there, poised between divergent paths, Leo finally grasped the extent of the gamble he faced. He knew what truly dwelled within those orbitals—the promise of annihilation versus rescue alongside a mysterious iconoclast whose allegiances blurred between heroism and outlawry. His world had been shattered as abruptly as an asteroid strike; his certainties shattered like fragile ice in a furnace.

Ultimately, Commander Leo Mercer realized there were no easy choices left, only impossible trade-offs and agonized compromise—the sacrifices required to save some at the cost of others.

✦ ✦ ✦

The bulkhead screens trembled like a web about to snap as Leo backed out of the cockipit, his eyes never leaving the starfield unfolding before Vex. The void's silent majesty belied the turmoil roiling within him—a maelstrom of duty, desperation, and trepidation.

Beyond the ship's battered hull, the warzone stretched out in eerie stillness, each orbiting stronghold a pinprick of flickering light against the coal-black canvas of space. They looked almost... serene, save for the knowing dread that had become etched upon every pilot's countenance. Leo forced himself not to contemplate the thousands—no, tens of thousands—of deaths those beacons represented, or how many more would follow should hope falter and fail.

"It feels like staring into the abyss," he muttered, absently tracing a gloved finger along the chill metal, drinking in the reassuring solidity of the ship's skeleton. This living sanctuary was a counterpoint to the unfathomable vastness reigning supreme outside, a testament to human ingenuity and stubborn resilience.

"More like gazing into destiny herself," Vex replied, voice carrying through the comms as she leaned back in her command chair. Her boots kicked idly against the instrument panel, the metallic rings chiming softly in the oppressive quiet. "One look tells you she can swallow this entire galaxy whole, yet here we are—tiny motes, dancing on winds of time, clinging to existence against the very forces that birthed us."

Her words hung heavy in the air, resonant echoes of the existential questions plaguing Leo's mind. In that moment, the distance separating them seemed to collapse, bridged by something far deeper than the void between ships—it was the common ground of mortality, the fear-laced thrill of facing the unknown shoulder to uncloaked shoulder. And perhaps... perhaps a nascent camaraderie born from the shared knowledge that tomorrow might not come for either of them.

Suddenly, the Marauder lurched, a jarring impact shaking the deck plates beneath their feet with enough force to knockLeo slightly off balance. Alarms flashed across the screens in chaotic staccato bursts, drowning out the faint hiss of vented atmosphere bleeding into the vacuum.

"Hold on!" Vex growled, fingers flying across her console. "We've got a new contact—a Class-F anomaly, possibly hostile, bearing nine-point-eight degrees off our port stern. Closing fast..."

In that instant, every ounce of training and instinct screamed at Leo to reach for his firearm or strap back into the escape pod. But he hesitated, locked into place as if a magnetic undertow yanked at his very soul.

Through the comm window, Vex's expression tightened into a brutal mask of focus—"Leo! Prepare for evasive maneuvers!"—but he barely heard her over the roaring vortex spinning in his head. For an eternity stretched taut like a drawn bowstring, he remained frozen, transfixed, as the mystery closing in upon them began to take form...

A pulsar-shaped monolith flared suddenly into radiant prominence across the viewport's expanse—a beacon blazing brighter than any star, searing the retina even through polarized shielding. The very fabric of space appeared to warp and buckle around it, reality reshaping itself like a lover's embrace in a mad whirlwind of light and fury.

"Oh sweet Chaos..." Leo breathed, awestruck and terrified to his core. "...what IS that thing?"
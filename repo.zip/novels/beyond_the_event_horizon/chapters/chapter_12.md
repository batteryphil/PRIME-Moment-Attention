# Chapter 12: The Deceleration Burn

Darkness yawned before them like bottomless infinity, the abyssal void pierced only by pinpricks of distant stars strewn across the velvet black. Yet their attention was riveted not upon celestial ballet, but on data streams coursing through HUDs and the tactical display at the heart of the command console. Here, amidst the pulsing lume of holographic projections, lay the sole lifeline through which hope could still thread itself back into Leo Mercer's shattered existence.

With each passing second, their velocity relative to the approaching mass ticked downward at a agonizing glacial pace, thrust vectors compensating, counterbalancing the relentless deceleration that would soon crush flesh and bone to jelly against unyielding metal and ceramic armor plating. But even at sixty percent of max g-forces—well beneath what the Harbinger had endured—Leo's body screamed its protest even through the numbing bite of cryo-enhanced pain tolerance woven into his genetic makeup. Each breath was a laborious battle, lungs straining to expand amidst the unending, merciless pressure that threatened to collapse chest cavity walls inward like a punctured air sac.

Coppery tang of blood trickled at the corners of his mouth, the metallic flavor mingling unpleasantly with the stale recycled atmosphere of the cramped bridge. Perspiration, slick with condensation, clung to skin, leaving faint phantom patterns that rippled as they twitched involuntarily against straps binding them in seat frames designed to compress and cushion during extreme negative-g flights not anticipated by the Starlight Marauder's design parameters. Still, even amidst such hellish torment, Astrid remained steadfast throughout the chaos, her features etched with an almost monk-like intensity that bespoke years, if not decades, of surviving environments as cruel as those they currently faced.

Yet despite her icy focus, Leo sensed the tremble in her hand, barely perceptible but present nonetheless, a sign of the strain exacted by this unprecedented emergency. He glanced sideways, meeting the fierce gaze burning out of her shadow-darkened eyes—and saw himself reflected in that unfathomable depth—adrenaline-fueled wildness tempered by grim purpose distilled down to pure, unyielding will. That spark, he realized with sudden clarity, held secrets even more profound than the quantum anomalies haunting this forbidden corner of the cosmos...

Time seemed to stretch and contract in tandem with their plummeting velocity, each heartbeat stretching out toward eternity while centuries flashed by faster than thought. There was no room for distraction, for emotional indulgence or frivolous speculation, not when every gram of precious fuel, every carefully conserved watt-second of power, stood poised to either salvation—should they correctly calculate their approach—or annihilation should an errant millimeter toss the Marauder out of control into the ravening maw awaiting them ahead.

Leo swallowed audibly, fighting down the rising bile that roiled ominously in his stomach, threatening to spill forth as nausea. He locked eyes with Astrid once more and nodded infinitesimally, understanding passed silently between them like an electrical current surging over freshly forged bonds of partnership forged in desperation and shared peril; together, and alone within this godforsaken stellar crucible, they would confront whatever darkness waited to greet them head-on or be consumed utterly in the making of it.

Leo's throat constricted. Time to face the music—his own very life hanging precariously in balance with the outcome of this gamble that could prove his last, final stand against extinction. He steeled himself, jaw clenching tight as ancient mantra echoed through his mind: Don't look back. Never retreat.

✦ ✦ ✦

The chittering cacophony of a thousand diamond shards pierced Leo's eardrums even through his helmet, yet still resonated with eerie, otherworldly clarity, underscored by the grinding screech of metal on approaching stardust that grew exponentially with each passing second. This tortured symphony served as grim counterpoint, an endless discord that wove itself relentlessly around Leo's core dread—a chill akin to staring past the veil of mortality itself.

Leo gritted his teeth until they ached, a physical manifestation of the bitter struggle to suppress the mounting anxiety that threatened to consume him whole. Every agonizing tick marked another irrevocable surrender of speed he might never regain again—the fleeting hope of rescue dwindling to a dying ember behind them as they hurtled unrelentingly toward certain doom if they veered but a hair off course.

As gut-wrenching terror edged out strategy and rational thought, Leo's gaze involuntarily strayed toward the viewscreen before snapping back into focus. He couldn't afford these lapses, and he damned the traitorous impulse. Astrid's measured cadence provided comforting normalcy amidst the chaos—a soothing melody amid the tempest. When she spoke again, her words cut through his desperate spiral:

"You're thinking we should've taken harder evasive maneuvers earlier?" She framed the question starkly, a challenge almost as much as genuine inquiry. "Or maybe you thought we'd just coast right up to the event horizon and tap dance for the abyss?"

Leo hesitated, seized by the nagging uncertainty festering in his chest. His gut screamed the truth, that he and Astrid were playing a game of astronomical Russian roulette—and both of them weren't quite betting man enough to see it through till the bitter end. Still, some vestige of old-school arrogance demanded argument.

"We didn't have enough precise orbital data when we jumped the transwarp gate," he pointed out gruffly. "And taking too radical a turn would've flung us straight into Sol's corona instead of setting us on approach—"

"Macho theories and outdated principles, is what," Astrid interjected, her voice dripping acid. "Your precious twenty-first century protocols don't factor for the freak quantum instability that brought you screaming through the void in the first place, Commander Mercer. You can't blame me for thinking you're about as useful as a solar-powered fusion generator trying to navigate my ship in an active black hole."

Her words hung heavy with disdain, the sting of which Leo felt all the way to his bones. Astrid wasn't wrong—his training manuals made no allowance for such unhinged circumstances—but that didn't make her cutting jabs any less galling. Yet Leo held firm, refusing to show weakness under duress.

"Just because my methods aren't aligned doesn't mean there's anything inherently wrong with them," he pressed stubbornly. "You may have the advantage in sheer numbers, firepower, and—apparently—your pirate pragmatism, but at the heart I'm talking strategy grounded in tried and true principles honed millennia before the advent of your wild-west, lawless cosmos. My tactics get men home alive where yours... well, let's just say they tend to acquire assets rather than risk everything for the slenderest chance of survival."

"Ideals versus instincts, perhaps," Astrid remarked dryly, but her tone mellowed slightly, hinting at some begrudging respect beneath her defensive posturing. "At our core, neither's wrong. But neither guarantees our success here." A pause weighted with meaning passed between them, both sensing the razor's edge upon which their unlikely alliance teetered.

✦ ✦ ✦

Chapter Twelve: The Deceleration Burn

The universe outside became a swirling vortex of iridescent colors—opals, amethysts, emeralds—as if the very fabric of reality had been rent asunder by Astrid's reckless maneuvering. Stars streaked past in chaotic pinwheels, each one a searing pinpoint of light against the inky void.

Leo gripped the acceleration couch with white-knuckled force, cheeks sucked inward, and eyelids clamped shut as the Marauder corkscrewed through the heart of a black hole's accretion disk. Gravitational forces warped space-time around them, compressing matter to unimaginable densities mere kilometers away. The starship's fragile hull groaned in protest at the strains placed upon it.

"You bloody madwoman!" Leo roared above the cacophony of tortured metal, screeching thrusters, and the ominous booming of gravity waves through the hull plating. Sweat soaked his face, stinging eyes, dripping onto his uniform collar. Each passing second stretched time itself thinner, a relentless countdown until they overshot the event horizon forever lost within the abyss.

Astrid's voice cut through the din, sharp as a laser beam. "Mercer, we need more delta-V! Engage afterburners and fire every torpedo on station! Now!"

"No—"

But before Leo could argue further, the bridge's artificial gravity lurches, throwing both crew members off balance. The inertial dampeners were faltering, overwhelmed by the ship's frantic pace.

Astrid recovered faster, scrambling upright with feline grace despite the microgravity turbulence. Leo fumbled for handholds as the floor underfoot seemed to undulate like the deck of a ship caught between swells during a tempest, threatening at any moment to toss him and everything else loose into the inky expanse.

His stomach twisted, queasy with the knowledge that should this beast of a vessel breach containment and vent its atmosphere, they'd be cooked alive within seconds by the blistering plasma flows and radiation from the surrounding singularity's superheated disk.

"Hold on to something, Mercer!" Astrid yelled, strapping herself back into the command chair, her face set in grim determination. "We're going nose first into the Maelstrom."

Leo barely registered the cold metal buckle digging into his hipbone as panic clawed at his insides, a visceral response born not from fear but from the raw intimacy of being utterly helpless, poised on the precipice of annihilation alongside this ruthless yet strangely captivating pirate captain.

Their gazes clashed in the dim light of the bridge, Astrid's eyes ablaze with an unsettling mix of exhilaration and resignation. In that fleeting instant, it was as though she saw not merely a stranded stranger but the man beneath the layers of discipline and rationality—the same man who'd so tenaciously stuck to his ideals even while dangling over the edge of oblivion.

"I've never met anyone quite like you, Mercer," she said, and for an inexplicable reason, it sounded almost like an admission rather than a dismissal. She tilted her head quizzically, acknowledging the unspoken truth hanging in the air between them—their shared conviction in the primacy of their respective methods notwithstanding.

Her lips curled into that familiar enigmatic smirk just before they closed the distance between their faces, pressing palms against a shared console, their chests brushing, electrifying and perilous as a spark of static energy.

It was only supposed to last a nanosecond—just long enough to steal another glance at those startling blue eyes—yet somehow that infinitesimal touch transformed into a prolonged pause, charged.

✦ ✦ ✦

CHAPTER 12: THE DECELERATION BURN 

Scene 4

They stood shoulder to shoulder, hands bracing against the trembling console, bodies swaying subtly as if mirroring each other's ragged breaths. Outside, the sky was a living canvas—a dynamic interplay of nebulae swirling in shades of fiery vermillion and electric azure, their ethereal tendrils reaching across unfathomable stretches of empty space.

"Hold on to something!" Astrid barked, her voice echoing hoarsely within the confined bridge. The words were less a command than a desperate prayer for both of them. With a fierce, grinding protest, the Starlight Marauder began its final deceleration burn—a vicious spiral down to the planet's surface, a frantic dance to shed speed by robbing momentum from her very structure.

Leo tightened his grip on the console, knuckles white with tension. He couldn't tear his gaze away from the navigation display: a dizzying web of vectors, gravity wells, and treacherous asteroid belts stretching to infinity. Each line, every arc, was a promise of annihilation should their calculations falter even by a fraction. And they were already pushing well beyond what most starships would dare attempt.

The ship shuddered violently as the engines roared, spewing torrents of ionized plasma in a dazzling streak that briefly illuminated the cosmos. The deck creaked ominously beneath their feet like a bowstring stretched taut, threatening at any moment to snap back with brutal force. Sweat trickled down Leo's face, stinging his eyes in the dry atmosphere, yet he refused to blink, focusing solely on the data streaming across screens before him.

Seconds seemed like minutes as they teetered on a hairline trigger, simultaneously masterminds orchestrating a suicidal ballet and helplessly passengers trapped aboard the Marauder's hull. Until finally, agonizingly slowly, the engine roar softened to a guttural rumble and then dropped to a mere tremor...

Silence fell, broken only by the steady thrum of idling engines and the soft hiss of atmosphere recycling. For a span of heartbeats that stretched into seconds, no one moved or spoke.

Then a blaring alert shrilled out from the comms array, momentarily making them leap apart in surprise. The words 'Unknown Contact' flared across the display in strobing red letters right before the transmission cut off abruptly, leaving nothing but dead air.

Astrid cursed colorfully under her breath, eyes narrowing as she fiddled with her comm panel. "Get me tactical on—" A look of dawning realization crossed her features. She stabbed a finger at the viewscreen as a new image replaced the starfield—a gargantuan structure dominating the horizon below.

"That can't be right..." Leo muttered, peering skeptically at the angular silhouette looming amidst wispy cirrus clouds. Towers and ramparts of dark iron-gray metal reached toward the heavens, casting long shadows as night began to fall.

"That's not natural architecture,' Astrid growled low in her throat. Something in her tone sent a chill down Leo's spine—an awareness that defied logic but resonated deep in his gut—that whatever awaited them beyond the horizon bore no resemblance to anything humanity had created.

She spun to face him, eyes dark and intense. "Mercer... ready some serious firepower."

In that moment, as the mysteries of the unknown beckoned and the eerie silence of the ship's interior pressed in around them, there could be no illusions about the perils ahead. Yet amidst the impending storms, both commanders held onto grudging respect for each other—a bond forged through adversity and an unlikely understanding.
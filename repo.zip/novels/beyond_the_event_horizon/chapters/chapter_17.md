# Chapter 17: Flight of the Ancient Torch


The stars blurred as Reliant surged forward, shedding momentum shed during its prolonged descent into the outer reaches of Ragged Rift. Thrusters flared white-hot, burning precious xenon gas in a futile bid to dodge the hail of weapons fire raining down from above. Alarms howled, strobing red beneath his gloved hands. The cockpit reeked of scorched copper and ozone, acrid smoke stinging Vex's eyes like acid rain.

Leo focused intently on his instruments, muscles tensed to react to any aberrant maneuver cue. Every instinct screamed at him to flee, to escape this hellish maelstrom. But in this hand-crafted relic of yesteryear, fleeing was nearly impossible. Each deliberate shift required precision calculation, defying the intuitive quick-reactive reflexes ingrained by thousands of hours at the controls of his sleek, über-capable F/A-37F Fury — fighter ace Leo Mercer's legendary mount.

Here, every minor correction demanded grueling mental effort, painstaking computations performed on slide rules instead of slick touchscreens. Modern AI wouldn't have stood a chance either, given the limitations imposed by Reliant's antique architecture. No, only raw human ingenuity kept them alive this long. Leo hoped it would be enough.

"Celestial hell, I'm getting tired of being this aircraft's crash test dummy," he muttered over his shoulder at Vex, who shot back an uncharacteristically tight-lipped reply.

A searing lance of pain exploded behind Leo's eyes as an unseen concussion slammed into Reliant's flank. Sirens shrieked, shrill overkill designed to shatter even the most stalwart pilot's concentration. The g-forces crushed inward, rib cage compressing painfully while adrenaline surge after surge threatened to boil blood within his veins.

He gritted his teeth, ignoring the screaming in his head, and wrestled the rudder harder to port, barely maintaining control despite the ship's listing. Barely keeping pace with Vex's daredevil piloting.

Outside, the nebula's roiling clouds reflected Relient's tormented trajectory: convulsive surges and desperate turns marked in staccato bursts of ionizing plasma against the starry blackness. As if to punctuate the mayhem, a shower of stars winked out in an instantaneous, eerie celestial extinction event, bracketed by blinding suns forging from swirling eddies of hot plasmas dancing in the heart of a vast binary system.

"That'll teach me to pick fights in the Rift!" Vex spat venomously over her suit comms. "If we don't break contact soon, Raptor will be too close before we can slip their ambush!"

Reliant bucked violently once more, its primitive frame buckling under further assaults, groaning like tortured metal. In the flickering shadows cast by the instrument panels, Vex's visage was twisted in grim determination. It seemed no matter what they threw at her, their battered flight still clung tenaciously to life.

With a ragged gasp, she snatched up the worn, leather-bound manual lying open across the center console's armrest. Tattered pages rustled softly as she thumbed through, searching desperately for an answer. The ancient text, its knowledge frozen in carbonite for millennia, remained the ship's sole remaining guide — along with the duo's own wits — against overwhelming odds. Only one thing could possibly give them an edge, provided Mercer bought her the time: exploiting Reliant's unique capabilities in ways no computer program dared attempt.

"Leo, think fast."

✦ ✦ ✦

Leo's heart jackhammered against his ribcage as he wrestled with the controls, hands shaking with a mixture of fear and desperation. Outside, spiraling relativistic projectiles punched glowing holes through Reliant's armored hide like needles piercing fabric. A shrill ping hammered his senses – again, another breach to seal, another patch to weld in place.

"No joy in killing the messenger," Vex grunted, tossing him a plasma wrench. Her calloused hand brushed his as she handed over the tool, sending tingles racing up his spine despite the urgent chaos around them.

"Just get that hole shut before I implode every oxygen tank trying not to," Leo clipped back, taking the wrench with numb fingers. He ducked away as Reliant lurched starboard, smacking into the bulkhead beside him hard enough to make his vision blur. Amidst the cacophony of alarm klaxons, thrumming engines screaming to full burn, and the agonized screech of tortured metals – some part of him marveled that either of them could still think straight.

Leo yanked the makeshift repair kit free from its stowed compartment, tearing open containers of specialized epoxy, woven nanomesh, and reinforced polymer sheets. Time was a luxury they couldn't afford anymore – every second counted as Raptor bore down relentlessly, its pursuers intent on tearing apart any piece of wreckage to claim the Starlight Marauder's secrets. Forcing aside his dread, he attacked the task with focused intensity, fingers flying as he rapidly applied layers of reinforcement after reinforcement, praying it would hold long enough.

"You're doing great," Vex praised, her voice low but encouraging, even as she pored over the tattered manual.

"Yeah, well, might have something to do with your crew not exactly being the poster children for maintenance," Leo muttered, pausing to catch his breath. Before Vex could retort, he slapped yet another final sheet of protective shielding in place, twisting the locking latches with gritted teeth until they clicked securely.

"Breathable again, but if it blows..." An unspoken threat hung in the air – with Raptor closing fast, and no hope of outrunning them now, whatever happened next, this fragile refuge wouldn't last long.

Leo met Vex's stormy gaze, seeing there the same blend of frustration, relief, and grim resolve churning within her scarred features. The tension between them crackled like arcing energy, born of shared danger, enforced proximity, and long-suppressed differences waiting to boil over. Even now, as relativistic death rained from the stars above, somehow the fight between them felt just as personal – a battle for supremacy as much as survival, old world honor versus wild frontier pragmatism.

"We don't have much choice left," Vex said finally, flipping a few pages in the leather manual with an impatient swirl of fingers. "According to this relic, the Reliant wasn't originally designed as a fighter. Never had to be – its capabilities went beyond anything built today." She squinted at the cryptic notation, lips moving silently. "It says something about... exploiting the void itself? Gravity manipulation? It sounds like fringe science twaddle, but—"

"There's definitely truth to it somewhere," Leo interrupted, memories sparking from centuries-old flight manuals back on Earth: grainy images of Reliant conducting secret gravity experiments in nearspace decades ago, predating today's understanding of gravitomagnetism. Old theories merged into new hypotheses, casting innovative scenarios to push past delta-v constraints.

"—if used right, it could conceivably alter our trajectory out from under Raptor's guns," Leo continued.

✦ ✦ ✦

The Reliant's fusion drives roared to life, screaming protest at the sudden jolt of power poured through their plasma cores. Grappling yanks wrenched Leo off balance against his reinforced harness, while Vex clung tenaciously to the co-pilot's seatback railings, bracing herself for the monumental acceleration to come.

"Buckle up tighter," Leo yelled above the piercing shriek filling the tiny cockpit cavity. Vex shot him an incredulous look but obeyed promptly, the sudden rumble beneath them unmistakable as the Reliant hauled its mass into a desperate, high-delta-V turn.

Orbiter-mounted laser arrays scythed past astern, searing streaks of ruby-white across the night. Flashes erupting from their origins revealed Raptor's position: a lumbering, black-silhouetted behemoth trailing plasma plumes from afterburners engaged full-throttle in hot pursuit. Laser beams carved glowing furrows in nearby asteroids as they attempted to bracket their quarry, driving asteroids as makeshift shields against retaliatory weapons.

Leo gripped the control stick so firmly his knuckles turned white, eyes straining down the main viewscreen as the Reliant corkscrewed wildly through the asteroid field, evading point-blank death by mere meters. Every instinct screamed at him to pull up, go vertical until he'd shed some of that relative speed, but he knew desperation would drive Raptor toward even more reckless gambles if he gave them an easy shot. His only hope was to wear them down until...

A lurch caught him by surprise, rattling both pilots. Main drives sputtered and died as the inertial dampeners hiccuped and then failed altogether. For a heart-stopping instant, gravity reversed as they freefall-flew into a spinning, unstable tumble deep amongst drifting rocks — before the secondary reaction thrusters kicked in on a manual override command Leo barely registered issuing himself. The ship stabilized erratically and crawled forward under the pilots' grim determination.

"We're out of warp, and I've got fuel for another three engine-light orbit max," Vex reported succinctly, her voice edged with strain amid pounding heartbeat.

Leo scanned displays frantically, trying to work out options with depleted stores. Time wasn't their friend anymore. "Maybe enough to set ourselves up as bait for a beam race, keep them busy," he suggested tightly, mentally walking through the dangerous plan. "But we can only hope they take the dive once the shielding's been stripped away."

He glanced over at his battle-weary copilot, who returned the gaze with a ghost of her old mirthless snarl, even while crimson rivulets seeping from creased skin spoke of far more than mere fatigue. The unspoken bond between these polar opposites grew taut as the strained metal of their battered vessel, forged through unthinkable perils side-by-side...

In the fraught pulsing seconds of silence hanging heavy between them, a precipice of closeness seemed almost palpable, the invisible currents sparking between wary commander and lethal corsair reaching its fever pitch. They stared into each other's faces, features stark under harsh light, a dizzying amalgam of sweat-dampened locks, jagged scars, wide-set eyes shimmering in the gloom of a cockpit alive with flashing indicators and looming doom.

Leo swallowed audibly; the dryness of his own mouth seemed echoed by the parched tightness of Vex's grip on the armrests. Her gaze held his with unnerving intensity, as if committing each detail to private memory...

✦ ✦ ✦

The mariner's knot of adrenaline in Vex's stomach finally released its tensile hold as the impossible happened − their pursuers broke off the attack and disappeared into the swirling vortex of debris field and re-entry burn. For a few crucial breaths she simply let herself shudder, exhaling raggedly as shock waves rippled throughout her petite frame.

Her head lolled back against the padded restraint harness, dark hair a wild tangle plastered to her sweat-slicked skin. Eyes stung painfully as they cycled rapidly through recovery modes. "Merca fuckin' hell..." she ground out hoarsely. A shaky laugh escaped her before it could be arrested – not hilarity but pure incredulity echoing back from numb lips.

Leo reached across the consoles to clap Vex firmly on the shoulder, giving her a once-over with concern etched on his weathered face. "Think you're okay? Those shields are going to need hours to recharge."

"I'm still kickin'," she replied gruffly, shoulders squaring as weariness receded in the face of adrenaline's aftermath. She flexed hands within her gauntlets, fingers curling and extending like claws. Black-tarnished nails cut crescents into meat. "Helluva close call. If I didn't know better, I'd swear our dead ship just got us kicked back upstairs..."

Through the shattered viewport's rent in the hull, star-spangled vastness yawned in an unfathomably beautiful blur, every galaxy impossibly distant and large to human scale. Yet within this glittering cosmos of diamond dust lay danger too - lethal solar flares and roiling stellar winds capable of vaporizing any unshielded materials unlucky enough to cross their paths.

As reality outside began to sharpen back into focus, distant violet swirls resolved into twin supermassive black holes straddling a tortured, blazing pinwheel nebula, locked in death dance orbitals billions of kilometers apart yet gravitationally entwined in a macabre cosmic waltz. Gas clouds stretched between fathomless chasms, each glowing ribbon thousands of times wider than Luna orbiting Earth. Gravity wave distortions warped spacetime's fabric, wringing offshoot tendrils from those luminous streamers.

"By the gods..." Vex breathed, half-turned in her seat as if trying to flee the view. Dark lashes fluttered frantically as she blinked, struggling to parse the scales involved. After millennia of spacefaring civilization, encountering such raw cosmic displays no longer stirred awe but rather stark primal unease at how insignificant humankind truly was amid unending eternity's immensity.

And then...

Alert red brackets flashed around the holographic sensors' display, drawing their attention forward as one. A separate readout flickered into existence, identifying the nearby source as an anomaly emitting microwave radiation. Vex paled beneath smears of soot and engine grime. As the signature stabilized and decayed over seconds − unmistakable characteristics blossoming into clear patterns − her expression twisted agonized with a sudden understanding of unfathomable import. "Stars above... Merc!" She seized her comms console as if meaning to rip the unit from its housing.

"What –"

"We've got a message buoy!" she announced in a thin, desperate voice. "Incoming from near the Sol system's ecliptic plane, transponder code's something about... Terra Nova Foundation. Could be another salvage op looking for the same thing!" Fear made her words rush. "Or more likely some corp-security goon show looking to pick up where Luminosity's bounty hunters left off!"